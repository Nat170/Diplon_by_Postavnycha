function getQueryParam(param) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(param);
}

async function fetchPaintings(authorId) {
    try {
        const response = await fetch(`/paintings/${authorId}`);
        console.log("Show:", authorId);
        if (!response.ok) {
            console.error(`Failed to load paintings for author ${authorId}, status: ${response.status}`);
            return [];
        }
        return await response.json();
    } catch (error) {
        console.error('Error fetching paintings:', error);
        return [];
    }
}

function renderPaintings(paintings) {
    const container = document.getElementById('container-paintings');
    container.innerHTML = '';

    if (!paintings.length) {
        container.textContent = 'No paintings found';
        return;
    }

    paintings.forEach(painting => {
        const card = document.createElement('div');
        card.classList.add('painting-card');

        const img = document.createElement('img');
        img.src = painting.image_url;
        img.alt = painting.title || 'Painting';
        img.classList.add('painting-image');

        const title = document.createElement('div');
        title.textContent = painting.title || 'Untitled';
        title.classList.add('painting-title');

        const year = document.createElement('div');
        year.textContent = painting.year ? `Year: ${painting.year}` : '';
        year.classList.add('painting-year');

        const location = document.createElement('div');
        location.textContent = painting.location ? `Location: ${painting.location}` : '';
        location.classList.add('painting-location');

        card.appendChild(img);
        card.appendChild(title);
        card.appendChild(year);
        card.appendChild(location);

        if (painting.wiki) {
            const wikiLink = document.createElement('a');
            wikiLink.href = painting.wiki;
            wikiLink.textContent = 'Learn more';
            wikiLink.target = '_blank';
            wikiLink.classList.add('painting-link');
            card.appendChild(wikiLink);
        }

        container.appendChild(card);
    });
}

async function init() {
    const authorId = getQueryParam('author_id');

    if (!authorId) {
        alert('Author ID is missing in the URL');
        return;
    }

    const paintings = await fetchPaintings(authorId);
    renderPaintings(paintings);
}

document.addEventListener('DOMContentLoaded', init);

const home = document.getElementById("home");
home.addEventListener("click", () => {
    window.location.href = `/`;
});