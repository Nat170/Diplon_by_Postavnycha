const svg = document.getElementById("map");
const container = document.getElementById("map-container");

const draggableTags = ["svg", "path"];

let zoom = 1.5;
let translateX = 0;
let translateY = 0;

let isDragging = false;
let dragStartX = 0;
let dragStartY = 0;
let startTranslateX = 0;
let startTranslateY = 0;

function updateTransform() {
    svg.setAttribute("transform", `translate(${translateX}, ${translateY}) scale(${zoom})`);
}

updateTransform();

container.addEventListener("wheel", (event) => {
    event.preventDefault();

    const direction = event.deltaY > 0 ? -1 : 1;
    zoom = Math.min(Math.max(1, zoom + direction * 0.5), 4);

    updateTransform();
});

container.addEventListener("mousedown", (event) => {
    if (!draggableTags.includes(event.target.tagName.toLowerCase())) return;
    event.preventDefault();
    isDragging = true;
    dragStartX = event.clientX;
    dragStartY = event.clientY;
    startTranslateX = translateX;
    startTranslateY = translateY;
    container.classList.add("dragging");
});

window.addEventListener("mouseup", () => {
    if (isDragging) {
        isDragging = false;
        container.classList.remove("dragging");
    }
});

window.addEventListener("mousemove", (event) => {
    if (!isDragging) return;

    const dx = event.clientX - dragStartX;
    const dy = event.clientY - dragStartY;

    translateX = startTranslateX + dx;
    translateY = startTranslateY + dy;

    updateTransform();
});