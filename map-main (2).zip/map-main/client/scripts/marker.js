import { show_author } from './show_author.js';

fetch('/markers')
    .then(res => res.json())
    .then(markers => renderMarkers(markers));

function renderMarkers(markers) {
    const svg = document.getElementById('map');
    const defs = createDefs(svg);
    const clusters = clusterMarkers(markers, 50);
    clusters.forEach((cluster, index) => renderCluster(svg, defs, cluster, index));
}

function createDefs(svg) {
    const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
    svg.appendChild(defs);
    return defs;
}

function clusterMarkers(markers, clusterDistance) {
    const clusters = [];

    markers.forEach(marker => {
        let added = false;
        for (const cluster of clusters) {
            const dx = cluster.x - marker.x;
            const dy = cluster.y - marker.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            if (dist < clusterDistance) {
                cluster.markers.push(marker);
                cluster.x = (cluster.x * (cluster.markers.length - 1) + marker.x) / cluster.markers.length;
                cluster.y = (cluster.y * (cluster.markers.length - 1) + marker.y) / cluster.markers.length;
                added = true;
                break;
            }
        }
        if (!added) {
            clusters.push({
                x: marker.x,
                y: marker.y,
                markers: [marker]
            });
        }
    });

    return clusters;
}

function renderCluster(svg, defs, cluster, index) {
    const { x, y, markers } = cluster;

    if (markers.length === 1) {
        renderSingleMarker(svg, defs, x, y, markers[0], index);
    } else {
        renderClusterCircle(svg, cluster);
    }
}

function renderSingleMarker(svg, defs, x, y, marker, index) {
    const { image_url, _id } = marker;
    const clipId = `clip-${index}`;

    const clipPath = document.createElementNS('http://www.w3.org/2000/svg', 'clipPath');
    clipPath.setAttribute('id', clipId);

    const clipCircle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    clipCircle.setAttribute('cx', x);
    clipCircle.setAttribute('cy', y);
    clipCircle.setAttribute('r', 12);
    clipPath.appendChild(clipCircle);
    defs.appendChild(clipPath);

    const img = document.createElementNS('http://www.w3.org/2000/svg', 'image');
    img.setAttributeNS(null, 'href', image_url);
    img.setAttribute('x', x - 12);
    img.setAttribute('y', y - 12);
    img.setAttribute('width', 24);
    img.setAttribute('height', 24);
    img.setAttribute('clip-path', `url(#${clipId})`);
    img.setAttribute('preserveAspectRatio', 'xMidYMid slice');
    img.classList.add('marker-image');
    svg.appendChild(img);

    const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    circle.setAttribute('cx', x);
    circle.setAttribute('cy', y);
    circle.setAttribute('r', 12);
    circle.classList.add('marker-circle');
    svg.appendChild(circle);

    const goToAuthor = () => {
        if (_id) {
            window.location.href = `/paintings?author_id=${_id}`;
        } else {
            console.error('No author ID found:', marker);
        }
    };

    circle.addEventListener('click', goToAuthor);
    img.addEventListener('click', goToAuthor);
}

function renderClusterCircle(svg, cluster) {
    const { x, y, markers } = cluster;

    const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    circle.setAttribute('cx', x);
    circle.setAttribute('cy', y);
    circle.setAttribute('r', 12);
    circle.classList.add('cluster-circle');
    svg.appendChild(circle);

    const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    text.setAttribute('x', x);
    text.setAttribute('y', y + 5);
    text.setAttribute('text-anchor', 'middle');
    text.classList.add('cluster-text');
    text.textContent = markers.length;
    svg.appendChild(text);

    const show = () => show_author(markers);
    circle.addEventListener('click', show);
    text.addEventListener('click', show);
}