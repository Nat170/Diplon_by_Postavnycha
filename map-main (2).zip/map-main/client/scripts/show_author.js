export function show_author(markers) {
    const panel = document.getElementById('info-panel');
    panel.innerHTML = '';

    markers.forEach(author => {
        const card = document.createElement('div');
        card.classList.add('author-card');

        const img = document.createElement('img');
        img.src = author.image_url;
        img.classList.add('author-image');

        const name = document.createElement('div');
        name.textContent = author.name;

        card.appendChild(img);
        card.appendChild(name);
        panel.appendChild(card);

        card.addEventListener('click', () => {
            window.location.href = `/paintings?author_id=${author._id}`;
        });
    });

    panel.style.display = 'flex';

    const onClickOutside = (event) => {
        if (!panel.contains(event.target)) {
            panel.style.display = 'none';
            document.removeEventListener('click', onClickOutside);
        }
    };

    setTimeout(() => {
        document.addEventListener('click', onClickOutside);
    }, 0);
}
