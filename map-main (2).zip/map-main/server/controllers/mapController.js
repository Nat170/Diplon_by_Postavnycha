const Marker = require('../models/marker');

exports.showMap = async (req, res) => {
    res.render('main');
};

exports.getMarkers = async (req, res) => {
    try {
        const markers = await Marker.find();
        res.json(markers);
    } catch (err) {
        res.status(500).json({ error: 'Server error' });
    }
};