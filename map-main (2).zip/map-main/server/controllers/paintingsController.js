const Painting = require('../models/painting');

exports.showPaintings = async (req, res) => {
    res.render('paintings');
};

exports.getPaintings = async (req, res) => {
    try {
        const authorId = req.params.authorId;
        const paintings = await Painting.find({ artist_id: authorId });
        res.json(paintings);
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch paintings' });
    }
};