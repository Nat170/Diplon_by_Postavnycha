const mongoose = require('mongoose');

const paintingSchema = new mongoose.Schema({
    artist_id: { type: mongoose.Schema.Types.ObjectId, ref: 'marker', required: true },
    title: { type: String, required: true },
    year: { type: String },
    location: { type: String },
    image_url: {type: String},
    wiki: {type: String},
});

module.exports = mongoose.model('painting', paintingSchema);