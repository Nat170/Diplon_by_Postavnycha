const mongoose = require('mongoose')

const markerSchema = new mongoose.Schema({
    name: { type: String, required: true, unique: true },
    x: { type: Number, required: true },
    y: { type: Number, required: true },
    image_url: { type: String, required: true},
});

module.exports = mongoose.model('marker', markerSchema);
