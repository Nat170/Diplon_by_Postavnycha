const express = require('express');
const router = express.Router();

const mapController = require('../controllers/mapController');
const paintingController = require('../controllers/paintingsController');

router.get('/', mapController.showMap);
router.get('/markers', mapController.getMarkers);
router.get('/paintings', paintingController.showPaintings);
router.get('/paintings/:authorId', paintingController.getPaintings);

module.exports = router;